const Hero = () => {
  return (
    <div className=" container vh-75 bg-primary">
      <div className="row justify-content-center align-items-center h-100">
        manav
      </div>
    </div>
  )
};

export default Hero;
